install.packages("stringi") # For text manipulation
install.packages("tm") # Framework for text mining
install.packages("dplyr") # Data preparation and pipes $>$
install.packages("ggplot2") # for plotting word frequencies
install.packages("wordcloud") # wordclouds!
install.packages("tidytext") # A tidy approach to text mining
install.packages("stm") # For structural topic models